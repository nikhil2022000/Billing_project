	<!-- App Footer start -->
    <div class="app-footer">© Uni Pro Admin 2021</div>
					<!-- App footer end -->

				</div>
				<!-- Content wrapper scroll end -->

			</div>
			<!-- *************
				************ Main container end *************
			************* -->

		</div>
		<!-- Page wrapper end -->

		<!-- *************
			************ Required JavaScript Files *************
		************* -->
		<!-- Required jQuery first, then Bootstrap Bundle JS -->
		<script src="{{'design/js/jquery.min.js'}}"></script>
		<script src="{{'design/js/bootstrap.bundle.min.js'}}"></script>
		<script src="{{'design/js/modernizr.js'}}"></script>
		<script src="{{'design/js/moment.js'}}"></script>

		<!-- *************
			************ Vendor Js Files *************
		************* -->
		
		<!-- Megamenu JS -->
		<script src="{{'design/vendor/megamenu/js/megamenu.js'}}"></script>
		<script src="{{'design/vendor/megamenu/js/custom.js'}}"></script>

		<!-- Slimscroll JS -->
		<script src="{{'design/vendor/slimscroll/slimscroll.min.js'}}"></script>
		<script src="{{'design/vendor/slimscroll/custom-scrollbar.js'}}"></script>

		<!-- Search Filter JS -->'
		<script src="{{'design/vendor/search-filter/search-filter.js'}}"></script>
		<script src="{{'design/vendor/search-filter/custom-search-filter.js'}}"></script>

		 <!-- Data Tables -->
		 <script src="{{'design/vendor/datatables/dataTables.min.js'}}"></script>
		<script src="{{'design/vendor/datatables/dataTables.bootstrap.min.js'}}"></script>
		
		<!-- Custom Data tables -->
		<script src="{{'design/vendor/datatables/custom/custom-datatables.js'}}"></script>
		<script src="{{'design/vendor/datatables/custom/fixedHeader.js'}}"></script>

		<!-- Download / CSV / Copy / Print -->
		<script src="{{'design/vendor/datatables/buttons.min.js'}}"></script>
		<script src="{{'design/vendor/datatables/jszip.min.js'}}"></script>
		<!-- <script src="{{'design/vendor/datatables/pdfmake.min.js'}}"></script> -->
		<script src="{{'design/vendor/datatables/vfs_fonts.js'}}"></script>
		<script src="{{'design/vendor/datatables/html5.min.js'}}"></script>
        <script src="{{'design/vendor/datatables/buttons.print.min.js'}}"></script>

		<!-- Main Js Required -->
		<script src="{{'design/js/main.js'}}"></script>

	</body>
</html>
<?php $__env->startSection('main-container'); ?>

<!-- Content wrapper scroll start -->
<div class="content-wrapper-scroll">

	<!-- Content wrapper start -->
	<div class="content-wrapper">

		<!-- Row start -->
		<div class="row gutters">
			<div class="col-xl-12">
                        <!-- Card start -->
                        <div class="card">
									<div class="card-body mt-4">
										
										<!-- Row start -->
										<div class="row gutters">
										<?php if(session()->has('message')): ?>
											<div class="alert alert-success">
												<?php echo e(session()->get('message')); ?>

											</div>
										<?php endif; ?>
											<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
											<form method="POST" action="<?php echo e(url('categories')); ?>">
                               					 <?php echo csrf_field(); ?>
												<!-- Field wrapper start -->
												<div class="field-wrapper">
													<input type="text" class="form-control" placeholder=" Enter Category Name" name="category_name">
													<div class="field-placeholder">Category Name</div>
												</div>
												<!-- Field wrapper end -->

											</div>
											<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
												
												<!-- Field wrapper start -->
												<div class="field-wrapper">
                                                <button type="submit" class="btn btn-primary" style="width: 199px;">Submit</button>
												</div>
												<!-- Field wrapper end -->

											</div>
											
										</div>
										<!-- Row end -->
</form>
									</div>
								</div>
								<!-- Card end -->

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('header_footer.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/easemyor/Billing_project/resources/views/Billing_file/billing_categories.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main-container'); ?>

<!-- Content wrapper scroll start -->
<div class="content-wrapper-scroll">

	<!-- Content wrapper start -->
	<div class="content-wrapper">

		<!-- Row start -->
		<div class="row gutters">
			<div class="col-xl-12">
                 <!-- Card start -->
                 <div class="card">
									<div class="card-body mt-4">
										
										<!-- Row start -->
										<div class="row gutters">
										<?php if(session()->has('message')): ?>
												<div class="alert alert-success">
													<?php echo e(session()->get('message')); ?>

												</div>
											<?php endif; ?>
											<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
											
											<form method="POST" action="<?php echo e(url('oprate')); ?>">
                               					 <?php echo csrf_field(); ?>
												<!-- Field wrapper start -->
												<div class="field-wrapper">
													<input type="text" class="form-control" placeholder=" Enter Operator " name="operator">
													<div class="field-placeholder">Operator </div>
												</div>
												<!-- Field wrapper end -->

											</div>
											<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
												
												<!-- Field wrapper start -->
												<div class="field-wrapper">
												
													<select class="form-select" id="formSelect" name="billing_cat">
													<?php $__currentLoopData = $dat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->category_name); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
													
													<div class="field-placeholder">Billing Cat</div>
												</div>
												<!-- Field wrapper end -->

											</div>
											
										</div>
										<!-- Row end -->
                                        <div class="row gutters">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">

											</div>
											
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
												
												<!-- Field wrapper start -->
												<div class="field-wrapper">
                                                <button type="submit" class="btn btn-primary" style="margin-left: 323px;">Submit</button>
												</div>
												<!-- Field wrapper end -->

											</div>
											
										</div>
</form>
									</div>
								</div>
								<!-- Card end -->

             </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header_footer.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/easemyor/Billing_project/resources/views/Billing_file/operators.blade.php ENDPATH**/ ?>